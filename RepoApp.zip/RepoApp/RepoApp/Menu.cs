﻿using System;
using System.Diagnostics;

namespace RepoApp
{
    /* @author Melizza Perez
     * @date 2/15/18
     * Class Menu lets the user choose what they wish to do with their local repository, 
     * and may ask them for general information involving the repository.
     **/
    class Menu
    {
        string url;
        string commitComment;

        /// <summary>
        /// The apps main menu
        /// </summary>
        public void MainMenu()
        {
            Console.WriteLine(
                  "-----------------------" +
                "\n** M A I N   M E N U **\n" +
                  "-----------------------");
            //asks user what they want to do with their repository
            Console.WriteLine("What would you like to do? Type in a number then press enter\n" +
                "[1]Create New Repository\n" +
                "[2]Update Existing Repository\n" +
                "[3]Commit/Push Local Repository\n" +
                "[4]Revert Repository");
            int input = Convert.ToInt16(Console.ReadLine());
            switch (input)
            {
                case 1:
                    NewRepo();
                    break;
                case 2:
                    UpdateRepo();
                    break;
                case 3:
                    CommitPushRepo();
                    break;
                case 4:
                    Console.WriteLine("This is a hard reset, you will lose uncommited changes.\n" +
                        "Are you sure? Press [Y] or [N]");
                    string resetSure = Console.ReadLine();
                    if (resetSure == "Y" || resetSure == "y")
                    {
                        RevertRepo();
                    }
                    break;
                default:
                    Console.WriteLine("That was not an option.");
                    break;
            }
        }

        /// <summary>
        /// Creates a new local repository
        /// </summary>
        public void NewRepo()
        {
            Console.Clear();
            //asks the user to enter the projects URL
            Console.WriteLine("Please enter in a url (ex. https://www.example.com)");
            url = Console.ReadLine();
            //finds the path of the new repo batch file
            string originalPath = Environment.CurrentDirectory;
            string finalPath = originalPath + @"\newRepoBatch.bat";
            //start batch file with the projects URL as a parameter
            Process.Start(finalPath, url);

            //asks user if they would like to branch
            Console.WriteLine("Would you like to work inside a certain branch? Press [Y] or [N]");
            string userInput = Console.ReadLine();
            if (userInput == "Y" || userInput == "y")
            {
                BranchLocalRepo();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("\nYOUR REPO IS IN THE FOLDER RepoApp>bin>Debug\n");
            }
        }

        /// <summary>
        /// Gets a new branch for the repository
        /// </summary>
        public void BranchLocalRepo()
        {
            Console.Clear();
            Console.Write("Please enter your branch name: ");
            string branchName = Console.ReadLine();
            //finds the path of the branching batch file
            string originalPath = Environment.CurrentDirectory;
            string finalPath = originalPath + @"\newBranchBatch.bat";
            //starts the batch file with the new branch name as a parameter
            Process.Start(finalPath, branchName);
            Console.Clear();
            Console.WriteLine("\nYOUR REPO IS IN THE FOLDER RepoApp>bin>Debug\n");
        }

        /// <summary>
        /// Pulls down from the remote repository
        /// </summary>
        public void UpdateRepo()
        {
            Console.Clear();
            Console.Write("Please enter your project folders name(capitalization matters!): ");
            string folderName = Console.ReadLine();
            //finds the path of the pull batch file
            string originalPath = Environment.CurrentDirectory;
            string finalPath = originalPath + @"\updateRepoBatch.bat";
            ///starts pull batch file and takes in the project 
            ///folder name as a parameter
            Process.Start(finalPath, folderName);
        }

        /// <summary>
        /// Commits changes and pushes them to the remote repository
        /// </summary>
        public void CommitPushRepo()
        {

            Console.Clear();
            //asks the user for a commit comment
            Console.Write(
            "Please note that this action will commit and " +
            "push your changes.\n" +
            "Please enter the comment for your commit: ");
            commitComment = Console.ReadLine();
            //asks user for folder name
            Console.Write("Please enter your project folders name(capitalization matters!): ");
            string folderName = Console.ReadLine();
            //asks user for username and email
            Console.Write("Username: ");
            string userName = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            //finds the pathof the commit/push batch file
            string originalPath = Environment.CurrentDirectory;
            string finalPath = originalPath + @"\commitPushBatch.bat";
            ///starts the commit/push batch file with the users comment, 
            ///the projects folder name, and user name/email as parameters
            Process.Start(finalPath, commitComment + " " + folderName + " " + userName + " " + email);
        }

        /// <summary>
        /// Reverts to the last time the repository has a commit
        /// </summary>
        public void RevertRepo()
        {
            Console.Clear();
            //asks the user for projects folder name
            Console.WriteLine("Please enter your project folders name(capitalization matters!): ");
            string folderName = Console.ReadLine();
            //finds the path of the revert repository batch file
            string originalPath = Environment.CurrentDirectory;
            string finalPath = originalPath + @"\revertRepoBatch.bat";
            ///starts the revert repo batch file with the project 
            ///folder name as a parameter
            Process.Start(finalPath, folderName);
        }
    }
}
