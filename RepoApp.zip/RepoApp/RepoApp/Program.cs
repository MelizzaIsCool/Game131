﻿namespace RepoApp
{
    /*
     * @author Melizza Perez
     * @Date 2/10/18
     * Class Program starts the application by calling the main menu
     **/
    class Program
    {
        /// <summary>
        /// Starts the program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Menu main = new Menu();
            main.MainMenu();
        }
    }
}
